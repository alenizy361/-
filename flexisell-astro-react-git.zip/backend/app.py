from flask import Flask, request, jsonify
import requests
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route("/paymob", methods=["POST"])
def create_payment():
    data = request.get_json()
    name = data.get("name")
    price = data.get("price")
    email = data.get("email")

    try:
        paymob_response = requests.post(
            "https://flexisell-api.replit.app/paymob",
            json={"name": name, "price": price, "email": email},
            timeout=10
        )
        result = paymob_response.json()
        return jsonify({"paymentUrl": result.get("paymentUrl", "")})
    except Exception as e:
        print("Error communicating with Paymob:", e)
        return jsonify({"error": "payment_failed"}), 500

@app.route("/ping")
def ping():
    return "API is running", 200

if __name__ == "__main__":
    app.run(debug=True)