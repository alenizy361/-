import { useState } from "react";

export default function SellApp() {
  const [user, setUser] = useState({ email: "", password: "" });
  const [loggedIn, setLoggedIn] = useState(false);
  const [product, setProduct] = useState({ name: "", price: "", description: "" });
  const [link, setLink] = useState("");
  const [messages, setMessages] = useState([]);
  const [messageInput, setMessageInput] = useState("");

  const handleLogin = () => {
    if (user.email && user.password) {
      setLoggedIn(true);
    }
  };

  const handleCreateLink = async () => {
    try {
      const res = await fetch("http://localhost:5000/paymob", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          name: product.name,
          price: product.price,
          email: user.email,
        })
      });
      const data = await res.json();
      if (data.paymentUrl) {
        setLink(data.paymentUrl);
      } else {
        alert("فشل إنشاء رابط الدفع");
      }
    } catch (error) {
      console.error("Payment Error:", error);
      alert("حدث خطأ أثناء إنشاء رابط الدفع");
    }
  };

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      setMessages([...messages, { sender: "أنت", text: messageInput }]);
      setMessageInput("");
    }
  };

  return (
    <div style={{ maxWidth: "600px", margin: "40px auto", padding: "20px", fontFamily: "Arial" }}>
      <h2>تسجيل الدخول</h2>
      <div style={{ marginBottom: "20px" }}>
        <label>البريد الإلكتروني</label><br />
        <input type="email" value={user.email} onChange={(e) => setUser({ ...user, email: e.target.value })} style={{ width: "100%" }} /><br />
        <label>كلمة المرور</label><br />
        <input type="password" value={user.password} onChange={(e) => setUser({ ...user, password: e.target.value })} style={{ width: "100%" }} /><br />
        <button onClick={handleLogin} style={{ marginTop: "10px" }}>تسجيل الدخول</button>
      </div>

      {loggedIn && (
        <>
          <h2>لوحة البيع</h2>
          <div style={{ marginBottom: "20px" }}>
            <input placeholder="اسم المنتج" value={product.name} onChange={(e) => setProduct({ ...product, name: e.target.value })} style={{ width: "100%", marginBottom: "8px" }} /><br />
            <input type="number" placeholder="السعر بالريال" value={product.price} onChange={(e) => setProduct({ ...product, price: e.target.value })} style={{ width: "100%", marginBottom: "8px" }} /><br />
            <textarea placeholder="وصف المنتج" value={product.description} onChange={(e) => setProduct({ ...product, description: e.target.value })} style={{ width: "100%" }} /><br />
            <button onClick={handleCreateLink} style={{ marginTop: "10px" }}>إنشاء رابط الدفع</button>
            {link && (
              <div style={{ background: "#eee", marginTop: "10px", padding: "10px" }}>
                <strong>رابط الدفع:</strong><br />
                <a href={link} target="_blank" rel="noopener noreferrer">{link}</a>
              </div>
            )}
          </div>

          <h2>المحادثة</h2>
          <div style={{ border: "1px solid #ccc", padding: "10px", height: "200px", overflowY: "scroll", marginBottom: "10px" }}>
            {messages.map((msg, idx) => (
              <div key={idx}><strong>{msg.sender}:</strong> {msg.text}</div>
            ))}
          </div>
          <input placeholder="اكتب رسالة..." value={messageInput} onChange={(e) => setMessageInput(e.target.value)} style={{ width: "80%" }} />
          <button onClick={handleSendMessage} style={{ marginLeft: "10px" }}>إرسال</button>
        </>
      )}
    </div>
  );
}
